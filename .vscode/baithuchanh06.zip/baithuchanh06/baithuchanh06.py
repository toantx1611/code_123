x=int(input("Nhập số: "))
if x%2==0:
    print("số chẵn")
else:
    print("số lẻ")