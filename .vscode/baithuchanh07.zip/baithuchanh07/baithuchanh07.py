x=int(input("nhập số thứ nhất: "))
y=int(input("nhập số thứ hai: "))
if x>y:
    print(True)
else:
    print(False)