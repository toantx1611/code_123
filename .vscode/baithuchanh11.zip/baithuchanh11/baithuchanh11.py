n=int(input("nhập số trong khoảng 1-9 :"))
if 1<= n <=9:
    print(f"\nBảng cửu chương{n}")
    for i in range(1,11):
         print(f"{n} x {i} = {n * i}")
else:
     print("Vui lòng nhập số trong khoảng từ 1 đến 9!")