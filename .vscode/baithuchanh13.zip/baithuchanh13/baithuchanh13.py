n = int(input("Nhập số lượng phần tử n: "))
dem_so_chan=0
for i in range (1,n+1):
    so=int(input(f"nhập số thứ{i}:"))
    if so%2==0:
        dem_so_chan+=1
print(f"Có {dem_so_chan} số chẵn trong {n} số đã nhập.")