t=float(input("nhập điểm toán:"))
v=float(input("nhập điểm văn:"))
a=float(input("nhập điểm anh:"))
diem_tb=(t+v+a)/3
diem_tb=round(diem_tb,2)
print("điểm trung bình ba môn là:",diem_tb)