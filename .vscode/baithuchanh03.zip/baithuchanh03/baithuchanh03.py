C=float(input("Nhiệt độ theo độ C hiện tại là:"))
F=C*9/5 +32
print("Nhiệt độ được quy đổi theo độ F là :",F)