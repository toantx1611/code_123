x=float(input("nhập điểm :"))
if x>=8:
    print("học sinh giỏi")
elif x>=6.5:
    print("học sinh khá")
elif x>=5:
    print("học sinh trung bình")
else:
    print("học sinh yếu")