dai=float(input("Nhập chiều dài"))
rong=float(input("Nhập chiều rộng"))
Chu_vi=2*(dai+rong)
dien_tich=dai * rong
print("chu vi hình chữ nhật là",Chu_vi)
print("diện tích hình chữ nhật là",dien_tich)