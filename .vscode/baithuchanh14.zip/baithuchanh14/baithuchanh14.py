n=int(input("nhập số cần đoán đúng:"))
so_lan_doan=0
while n<=10:
    so_doan=int(input("nhập số bạn đoán:"))
    so_lan_doan+=1
    if so_doan<n:
        print("số bạn đoán nhỏ hơn số cần đoán")
    elif so_doan>n:
        print("số bạn đoán lớn hơn số cần đoán")
    else:
        print("chúc mừng bạn đã chiến thắng")    
        #break