ten = input("Nhập tên của bạn: ")
tuoi = int(input("Nhập tuổi của bạn: "))

print(f"Tôi tên là {ten}, tôi {tuoi} tuổi.")
print(f"Sang năm tôi sẽ {tuoi + 1} tuổi.")