so_dien=int(input("nhập số điện:"))
if so_dien<=50:
    tien_dien=so_dien * 1800
elif so_dien<=100:
    tien_dien=50 * 1800 + (so_dien- 50) * 2000
else:
    tien_dien=50 * 1800 + 50 * 2000 + (so_dien - 100) * 2500
print("tiền điện là:",tien_dien)